from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import date, timedelta, datetime
from typing import Optional
import sqlite3

from database import init_db, get_db

# Initialize database on startup
init_db()

app = FastAPI(title="Task Tracker API")

# Enable CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- PYDANTIC MODELS (for request/response validation) ---

class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    priority: str  # Low, Medium, High
    due_date: Optional[str] = None  # Format: YYYY-MM-DD
    status: str = "todo"

class TaskUpdate(BaseModel):
    status: Optional[str] = None
    priority: Optional[str] = None

class TaskResponse(BaseModel):
    id: int
    title: str
    description: Optional[str]
    priority: str
    status: str
    due_date: Optional[str]

# --- HELPER FUNCTIONS ---

def row_to_dict(row):
    """Convert sqlite3.Row to dictionary"""
    return {
        "id": row["id"],
        "title": row["title"],
        "description": row["description"],
        "priority": row["priority"],
        "status": row["status"],
        "due_date": row["due_date"]
    }

# --- API ENDPOINTS ---

# CREATE TASK
@app.post("/tasks", response_model=TaskResponse)
def create_task(task: TaskCreate):
    # Validate priority
    if task.priority not in ["Low", "Medium", "High"]:
        raise HTTPException(status_code=400, detail="Priority must be Low, Medium, or High")
    
    # Validate status
    if task.status not in ["todo", "in_progress", "done"]:
        raise HTTPException(status_code=400, detail="Status must be todo, in_progress, or done")
    
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO tasks (title, description, priority, status, due_date)
        VALUES (?, ?, ?, ?, ?)
    """, (task.title, task.description, task.priority, task.status, task.due_date))
    
    conn.commit()
    task_id = cursor.lastrowid
    
    # Get the created task
    cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
    new_task = cursor.fetchone()
    conn.close()
    
    return row_to_dict(new_task)

# GET ALL TASKS WITH FILTERS
@app.get("/tasks")
def get_tasks(
    status: Optional[str] = Query(None),
    priority: Optional[str] = Query(None)
):
    conn = get_db()
    cursor = conn.cursor()
    
    # Build query with filters
    query = "SELECT * FROM tasks WHERE 1=1"
    params = []
    
    if status:
        query += " AND status = ?"
        params.append(status)
    
    if priority:
        query += " AND priority = ?"
        params.append(priority)
    
    # Sort by due_date
    query += " ORDER BY due_date ASC"
    
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    
    tasks = [row_to_dict(row) for row in rows]
    return tasks

# UPDATE TASK
@app.patch("/tasks/{task_id}", response_model=TaskResponse)
def update_task(task_id: int, task_update: TaskUpdate):
    conn = get_db()
    cursor = conn.cursor()
    
    # Check if task exists
    cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
    task = cursor.fetchone()
    
    if not task:
        conn.close()
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Build update query
    updates = []
    params = []
    
    if task_update.status:
        if task_update.status not in ["todo", "in_progress", "done"]:
            conn.close()
            raise HTTPException(status_code=400, detail="Invalid status")
        updates.append("status = ?")
        params.append(task_update.status)
    
    if task_update.priority:
        if task_update.priority not in ["Low", "Medium", "High"]:
            conn.close()
            raise HTTPException(status_code=400, detail="Invalid priority")
        updates.append("priority = ?")
        params.append(task_update.priority)
    
    if not updates:
        conn.close()
        raise HTTPException(status_code=400, detail="No fields to update")
    
    # Execute update
    params.append(task_id)
    query = f"UPDATE tasks SET {', '.join(updates)} WHERE id = ?"
    cursor.execute(query, params)
    conn.commit()
    
    # Get updated task
    cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
    updated_task = cursor.fetchone()
    conn.close()
    
    return row_to_dict(updated_task)

# GET INSIGHTS
@app.get("/insights")
def get_insights():
    conn = get_db()
    cursor = conn.cursor()
    
    # Get all tasks
    cursor.execute("SELECT * FROM tasks")
    all_tasks = cursor.fetchall()
    
    # Count by priority
    priority_counts = {"Low": 0, "Medium": 0, "High": 0}
    for task in all_tasks:
        priority_counts[task["priority"]] = priority_counts.get(task["priority"], 0) + 1
    
    # Count by status
    status_counts = {"todo": 0, "in_progress": 0, "done": 0}
    for task in all_tasks:
        status_counts[task["status"]] = status_counts.get(task["status"], 0) + 1
    
    # Due soon (next 7 days)
    today = date.today().isoformat()
    next_week = (date.today() + timedelta(days=7)).isoformat()
    
    cursor.execute("""
        SELECT COUNT(*) FROM tasks 
        WHERE due_date >= ? AND due_date <= ? AND status != 'done'
    """, (today, next_week))
    due_soon = cursor.fetchone()[0]
    
    # Overdue tasks
    cursor.execute("""
        SELECT COUNT(*) FROM tasks 
        WHERE due_date < ? AND status != 'done'
    """, (today,))
    overdue = cursor.fetchone()[0]
    
    conn.close()
    
    # Dominant priority
    dominant_priority = max(priority_counts, key=priority_counts.get)
    
    # Generate insight message
    total_active = status_counts["todo"] + status_counts["in_progress"]
    
    if total_active == 0:
        summary = "🎉 You're all caught up! No active tasks."
    elif overdue > 0:
        summary = f"⚠️ You have {overdue} overdue task(s). Time to catch up!"
    elif due_soon >= 5:
        summary = f"📅 Busy week ahead! {due_soon} tasks due in the next 7 days."
    elif dominant_priority == "High":
        summary = f"🔥 High priority work dominates your list. Stay focused!"
    else:
        summary = f"✅ Steady pace! {total_active} active task(s) to work on."
    
    return {
        "summary": summary,
        "priority_breakdown": priority_counts,
        "status_breakdown": status_counts,
        "due_soon": due_soon,
        "overdue": overdue,
        "total_tasks": len(all_tasks)
    }

# Health check
@app.get("/")
def root():
    return {"message": "Task Tracker API is running"}
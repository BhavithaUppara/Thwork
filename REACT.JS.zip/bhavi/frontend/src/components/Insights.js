import React from 'react';

function Insights({ data }) {
  if (!data) return <div className="insights">Loading insights...</div>;

  return (
    <div className="insights">
      <h3>💡 Smart Insights</h3>
      
      <div className="insight-summary">
        {data.summary}
      </div>
      
      <div className="insight-stats">
        <div className="stat-group">
          <h4>By Status</h4>
          <div className="stat-item">
            <span>📝 To Do:</span>
            <strong>{data.status_breakdown.todo}</strong>
          </div>
          <div className="stat-item">
            <span>⏳ In Progress:</span>
            <strong>{data.status_breakdown.in_progress}</strong>
          </div>
          <div className="stat-item">
            <span>✅ Done:</span>
            <strong>{data.status_breakdown.done}</strong>
          </div>
        </div>
        
        <div className="stat-group">
          <h4>By Priority</h4>
          <div className="stat-item">
            <span>🔴 High:</span>
            <strong>{data.priority_breakdown.High}</strong>
          </div>
          <div className="stat-item">
            <span>🟡 Medium:</span>
            <strong>{data.priority_breakdown.Medium}</strong>
          </div>
          <div className="stat-item">
            <span>🔵 Low:</span>
            <strong>{data.priority_breakdown.Low}</strong>
          </div>
        </div>
        
        <div className="stat-group">
          <h4>Urgency</h4>
          <div className="stat-item">
            <span>⚠️ Overdue:</span>
            <strong>{data.overdue}</strong>
          </div>
          <div className="stat-item">
            <span>📅 Due Soon:</span>
            <strong>{data.due_soon}</strong>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Insights;
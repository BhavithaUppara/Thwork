import React from 'react';

function TaskList({ tasks, onUpdateTask }) {
  const getPriorityColor = (priority) => {
    if (priority === 'High') return '#ff6b6b';
    if (priority === 'Medium') return '#ffa94d';
    return '#74c0fc';
  };

  return (
    <div className="task-list">
      <h2>📝 All Tasks ({tasks.length})</h2>
      
      {tasks.length === 0 ? (
        <p className="empty-state">No tasks found. Add one to get started!</p>
      ) : (
        <div className="tasks">
          {tasks.map((task) => (
            <div key={task.id} className="task-card">
              <div className="task-header">
                <h3>{task.title}</h3>
                <span
                  className="priority-badge"
                  style={{ backgroundColor: getPriorityColor(task.priority) }}
                >
                  {task.priority}
                </span>
              </div>
              
              {task.description && (
                <p className="description">{task.description}</p>
              )}
              
              <div className="task-meta">
                {task.due_date && (
                  <span className="due-date">📅 {task.due_date}</span>
                )}
              </div>
              
              <div className="task-actions">
                <label>
                  Status:
                  <select
                    value={task.status}
                    onChange={(e) => onUpdateTask(task.id, { status: e.target.value })}
                  >
                    <option value="todo">To Do</option>
                    <option value="in_progress">In Progress</option>
                    <option value="done">Done</option>
                  </select>
                </label>
                
                <label>
                  Priority:
                  <select
                    value={task.priority}
                    onChange={(e) => onUpdateTask(task.id, { priority: e.target.value })}
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </label>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default TaskList;